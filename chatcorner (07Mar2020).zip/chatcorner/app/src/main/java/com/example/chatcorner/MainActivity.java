package com.example.chatcorner;

import android.Manifest;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.app.job.JobWorkItem;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentCallbacks;
import android.content.ComponentName;
import android.print.PrinterId;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int MY_PERMISSION_REQUEST_RECEIVE_SMS = 0;
    EditText et_name, et_email, et_mobile;
    Button btn_Submit;
    private DBHandler dbHandler;

    private Switch wifiSwitch;
    private WifiManager wifiManager;
    ListView listView;
    private static final int  JOB_ID =  101;
    private JobScheduler jobScheduler;
    private JobInfo jobInfo;
    private JobWorkItem item;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        listView = (ListView) findViewById(R.id.listView);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
/*
        ComponentName componentName = new ComponentName(this,MJobScheduler.class);
        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,componentName);
        builder.setMinimumLatency(6*1000);
        builder.setRequiredNetworkType(jobInfo.NETWORK_TYPE_ANY);
        builder.setPersisted(true);

        jobInfo = builder.build();
        jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
        jobScheduler.schedule(jobInfo);*/


        ComponentName componentName = new ComponentName(this,MJobScheduler.class);
        JobInfo.Builder builder = new JobInfo.Builder(99,componentName);
        builder.setMinimumLatency(6*1000);

        //long flexMillis = 59 * 60 * 1000; // wait 59 minutes before executing next job

        /*JobInfo info = new JobInfo.Builder(1,componentName)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED) // change this later to wifi
                .setPersisted(true)
                .setPeriodic(60 * 60 * 1000, flexMillis)
                .build();
        new Intent("com.example.android.apis.ONE").putExtra("name", "One");*/
        //builder.setMinimumLatency(60*60*10000);
        //JobInfo.Builder builder = new JobInfo.Builder(99, new ComponentName(this,MJobScheduler.class)).setPeriodic(6*1000).build();
        jobInfo = builder.build();
        jobScheduler = (JobScheduler)getSystemService(JOB_SCHEDULER_SERVICE);
        jobScheduler.enqueue(jobInfo, new JobWorkItem(
         new Intent("com.example.android.apis.ONE").putExtra("name", "One")));




/*
        JobWorkItem item;
        Intent i;
        //first item
        i = new Intent();
        i.putExtra("Key1", "first item"); //fake data too.
        item = new JobWorkItem(i);
        jobScheduler.enqueue(jobInfo,item);
        //second item
        i = new Intent();
        i.putExtra("Key1", "Second item"); //fake data too.
        item = new JobWorkItem(i);
        jobScheduler.enqueue(jobInfo,item);
        //first item
        i = new Intent();
        i.putExtra("Key1", "Third item"); //fake data too.
        item = new JobWorkItem(i);
        jobScheduler.enqueue(jobInfo,item);*/






        /*Toast.makeText(this,"Job Scheduled...",Toast.LENGTH_SHORT).show();

*/



        int PERMISSION_ALL = 1;
        String[] PERMISSIONS = {
                // ADD Permission here & manifest
                android.Manifest.permission.CHANGE_WIFI_STATE,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.ACCESS_WIFI_STATE,
                android.Manifest.permission.GET_ACCOUNTS,
                android.Manifest.permission.READ_PHONE_STATE,
                android.Manifest.permission.INTERNET

        };

        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }

        wifiSwitch = findViewById(R.id.wifi_switch);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        wifiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    wifiManager.setWifiEnabled(true);
                    wifiSwitch.setText("WiFi is ON");
                    AddData();
                } else {
                    wifiManager.setWifiEnabled(false);
                    wifiSwitch.setText("WiFi is OFF");
                }
            }
        });

        dbHandler = new DBHandler(this);
/*
        et_name = findViewById(R.id.et_name);
        et_email = findViewById(R.id.et_email);
        et_mobile = findViewById(R.id.et_mobile);
        btn_Submit = findViewById(R.id.btn_Submit);*/
        et_name = findViewById(R.id.et_name);
        et_email = findViewById(R.id.et_email);
        et_mobile = findViewById(R.id.et_mobile);
        btn_Submit = findViewById(R.id.btn_Submit);

        btn_Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddData();
            }
        });
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED)
        {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS))
            {

            }
            else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, MY_PERMISSION_REQUEST_RECEIVE_SMS);
            }


        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION);
        registerReceiver(wifiStateReceiver, intentFilter);
    }
    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(wifiStateReceiver);
    }

    private BroadcastReceiver wifiStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int wifiStateExtra = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE,
                    WifiManager.WIFI_STATE_UNKNOWN);

            switch (wifiStateExtra) {
                case WifiManager.WIFI_STATE_ENABLED:
                    wifiSwitch.setChecked(true);
                    wifiSwitch.setText("WiFi is ON");
                    ArrayList<String> theList = new ArrayList<>();
                    Cursor data = dbHandler.getListContents();
                    if(data.getCount() == 0){
                        Toast.makeText(context, "There are no contents in this list!",Toast.LENGTH_LONG).show();
                    }else{
                        String queries="";
                        while(data.moveToNext()){
                            theList.add(data.getString(1));
                            ListAdapter listAdapter = new ArrayAdapter<>(context,android.R.layout.simple_list_item_1,theList);
                            queries = data.getString(data.getColumnIndex("reciever_num"));
                            //Object obj = ListAdapter.getAdapter().getItem(position);
                            //Toast.makeText(context, data.getString(2),Toast.LENGTH_LONG).show();
                            //listView.setAdapter(listAdapter);
                        }
                        Toast.makeText(context, queries,Toast.LENGTH_LONG).show();
                    }


                    break;
                case WifiManager.WIFI_STATE_DISABLED:
                    wifiSwitch.setChecked(false);
                    wifiSwitch.setText("WiFi is OFF");
                    break;
            }
        }
    };

    public void schedulerJob(View view) {
        jobScheduler.schedule(jobInfo);
        Toast.makeText(this,"Job Scheduled...",Toast.LENGTH_SHORT).show();
    }

    public void clearJob(View view) {
        jobScheduler.cancel(JOB_ID);
        Toast.makeText(this,"Job CANCELLED...", Toast.LENGTH_SHORT).show();
    }

    private void AddData() {
        if (et_name.getText().toString().isEmpty()) {
            et_name.setError("Name is required");
            et_name.requestFocus();
        }

        if (et_email.getText().toString().isEmpty()) {
            et_email.setError("Email is required");
            et_email.requestFocus();
        }

        if (et_mobile.getText().toString().isEmpty()) {
            et_mobile.setError("Mobile is required");
            et_mobile.requestFocus();
        } else {



            boolean isInserted = dbHandler.addData("123","send","rec","text","ate","time","ststus");


            if (isInserted) {
                Toast.makeText(this, "Data Inserted Successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], @NonNull int[] grantResults)
    {
        switch (requestCode)
        {
            case MY_PERMISSION_REQUEST_RECEIVE_SMS:
            {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    Toast.makeText(this, "Thank you to allow permission", Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(this, "Well i cant do anything until you permit me", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}

