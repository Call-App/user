package com.example.chatcorner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class    DBHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSIOAN = 1;
    private static final String DATABASE_NAME = "chichat.db";
    public static final String TABLE_PERSONAL = "sms_panel";

    private static String id = "id";
    private static String imei = "imei";
    private static String sender_num = "sender_num";
    private static String reciever_num = "reciever_num";
    private static String text = "text";
    private static String date = "date";
    private static String time = "time";
    private static String status = "status";

    public DBHandler(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSIOAN);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("Create Table " + TABLE_PERSONAL + "(id INTEGER PRIMARY KEY AUTOINCREMENT,imei text,sender_num text, " +
                "reciever_num text, text INTEGER, date INTEGER, time INTEGER, status INTEGER )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ TABLE_PERSONAL);
        onCreate(sqLiteDatabase);
    }
    public boolean addData(String Imei_num,String Sender_num, String Reciever_num, String Text,String Date, String Time,String Status){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(imei, Imei_num);
        cv.put(sender_num, Sender_num);
        cv.put(reciever_num, Reciever_num);
        cv.put(text, Text);
        cv.put(date, Date);
        cv.put(time, Time);
        cv.put(status, Status);
        long results = 0;
        try {
            results =  db.insert(TABLE_PERSONAL, null, cv);

        }
        catch(SQLiteException exception) {
            Log.i("error la inserare child", exception+"on the next line");
            exception.printStackTrace();
        }
        db.close();
        if (results == -1)
            return false;
        else return true;
    }

    private static class sqLiteDatabase {
    }
    public Cursor getListContents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE_PERSONAL ,null);
        return data;
    }
}
