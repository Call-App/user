package com.example.chatcorner;

import android.annotation.SuppressLint;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.os.AsyncTask;

/*
public class MJobExecuter extends JobService {

    @Override
    public boolean onStartJob(JobParameters params) {
        String query = "INSERT INTO `sms_panal` (`id`,`imei`, `sender_num`, `reciever_num`, `text`, `date`, `time`, `status`) VALUES (NULL,'123', '1235', '12', '14', '17', '15', '');";
        CallAPI callAPI = new CallAPI();
        callAPI.execute(query);
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}
*/

public class MJobExecuter extends AsyncTask<Void, Void, String> {
    //Context context;
    @SuppressLint("WrongThread")
    @Override
    protected String doInBackground(Void... voids) {
       // Toast.makeText(context,"hellow",Toast.LENGTH_LONG).show();
        String query = "INSERT INTO `sms_panal` (`id`,`imei`, `sender_num`, `reciever_num`, `text`, `date`, `time`, `status`) VALUES (NULL,'123', '1235', '12', '14', '17', '15', '');";
        CallAPI callAPI = new CallAPI();
        callAPI.execute(query);

        return "Background Long Runing Task Finished...";
    }
}